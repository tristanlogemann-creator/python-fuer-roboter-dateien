# ============================================================
# PROJEKT: Ampelsteuerung
# Durchlaeuft den klassischen deutschen Ampelzyklus und reagiert
# auf eine Fussgaenger-Anforderung per Taster.
# ============================================================

import ftrobopy
from time import sleep

txt = ftrobopy.ftrobopy("localhost", 65000)

rot = txt.output(1)     # Lampe an O1
gelb = txt.output(2)    # Lampe an O2
gruen = txt.output(3)   # Lampe an O3
taster = txt.input(1)   # Taster an I1

def alle_aus():
    # Hilfsfunktion: schaltet alle drei Lampen aus (siehe Funktionen, Teil 1)
    rot.setLevel(0)
    gelb.setLevel(0)
    gruen.setLevel(0)

def zeige_rot():
    alle_aus()
    rot.setLevel(512)

def zeige_rot_gelb():
    alle_aus()
    rot.setLevel(512)
    gelb.setLevel(512)

def zeige_gruen():
    alle_aus()
    gruen.setLevel(512)

def zeige_gelb():
    alle_aus()
    gelb.setLevel(512)

print("Ampel gestartet.")

while True:
    # Fussgaenger-Anforderung pruefen: bei ftrobopy bedeutet state() == 0,
    # dass der Taster gedrueckt ist (Kontakt geschlossen) - nicht 1!
    anforderung = taster.state() == 0

    zeige_rot()
    sleep(2)

    zeige_rot_gelb()
    sleep(1)

    zeige_gruen()
    if anforderung:
        # Bei Anforderung bleibt die Ampel kuerzer gruen
        sleep(3)
    else:
        sleep(6)

    zeige_gelb()
    sleep(1)
