# ============================================================
# BONUS-PROJEKT: Automatische Parkschranke
# Oeffnet bei Fahrzeugerkennung, bleibt kurz offen, schliesst
# dann automatisch wieder.
# ============================================================

import ftrobopy
from time import sleep

txt = ftrobopy.ftrobopy("localhost", 65000)

schranken_motor = txt.motor(1)      # Motor an M1
fototransistor = txt.voltage(1)     # Sensor an I1
fahrzeug_sensor_schwelle = 350      # vorher kalibrieren!

schranke_offen = False

def schranke_oeffnen():
    global schranke_offen
    print("Fahrzeug erkannt - Schranke oeffnet.")
    schranken_motor.setSpeed(400)
    schranken_motor.setDistance(90)
    while not schranken_motor.finished():
        pass
    schranke_offen = True

def schranke_schliessen():
    global schranke_offen
    print("Schranke schliesst.")
    schranken_motor.setSpeed(-400)
    schranken_motor.setDistance(90)
    while not schranken_motor.finished():
        pass
    schranke_offen = False

print("Parkschranke bereit.")

while True:
    helligkeit = fototransistor.voltage()
    fahrzeug_da = helligkeit < fahrzeug_sensor_schwelle

    if fahrzeug_da and not schranke_offen:
        schranke_oeffnen()
        sleep(5)          # Zeit zum Durchfahren
        schranke_schliessen()

    sleep(0.1)
