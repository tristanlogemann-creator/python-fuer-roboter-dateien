# ============================================================
# PROJEKT: Foerderband-Steuerung mit Uebergabe
# Band 1 laeuft dauerhaft. Erkennt der Sensor ein Bauteil an der
# Uebergabestelle, startet Band 2 kurz, um es zu uebernehmen.
# ============================================================

import ftrobopy
from time import sleep

txt = ftrobopy.ftrobopy("localhost", 65000)

band1 = txt.motor(1)             # Motor an M1
band2 = txt.motor(2)             # Motor an M2
fototransistor = txt.voltage(1)  # Sensor an I1

SCHWELLE = 400   # vorher kalibrieren
transportierte_teile = 0

print("Foerderband-Anlage gestartet.")
band1.setSpeed(300)
band2.setSpeed(0)   # Band 2 startet im Stillstand

while True:
    helligkeit = fototransistor.voltage()
    bauteil_da = helligkeit < SCHWELLE

    if bauteil_da:
        print("Bauteil an Uebergabestelle - Band 2 uebernimmt.")
        band2.setSpeed(300)
        sleep(1.5)          # genug Zeit, um das Bauteil zu uebernehmen
        band2.setSpeed(0)
        transportierte_teile += 1
        print(f"Transportierte Bauteile: {transportierte_teile}")

    sleep(0.1)
