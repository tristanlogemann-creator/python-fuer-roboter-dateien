# ============================================================
# PROJEKT: Sortiermaschine
# Foerderband laeuft dauerhaft. Ein dunkles Bauteil am Sensor
# loest eine kurze Weichenbewegung aus, um es umzuleiten.
# ============================================================

import ftrobopy
from time import sleep

txt = ftrobopy.ftrobopy("localhost", 65000)

foerderband = txt.motor(1)         # Motor an M1
weiche = txt.motor(2)              # Motor an M2
fototransistor = txt.voltage(1)    # Sensor an I1

HELLIGKEITS_SCHWELLE = 400   # vorher mit print() kalibrieren!
sortierte_hell = 0
sortierte_dunkel = 0

def weiche_umlenken():
    # Weiche kurz ausschlagen lassen und wieder zurueckstellen
    weiche.setSpeed(400)
    weiche.setDistance(90)
    while not weiche.finished():
        pass
    sleep(0.3)
    weiche.setSpeed(-400)
    weiche.setDistance(90)
    while not weiche.finished():
        pass

print("Sortiermaschine gestartet.")
foerderband.setSpeed(300)

while True:
    helligkeit = fototransistor.voltage()

    if helligkeit < HELLIGKEITS_SCHWELLE:
        print("Dunkles Bauteil erkannt - leite um.")
        foerderband.setSpeed(0)     # kurz anhalten fuer die Weichenbewegung
        weiche_umlenken()
        sortierte_dunkel = sortierte_dunkel + 1
        foerderband.setSpeed(300)  # Foerderband wieder starten
    else:
        sortierte_hell = sortierte_hell + 1

    print(f"Bisher sortiert - hell: {sortierte_hell}, dunkel: {sortierte_dunkel}")
    sleep(0.1)
