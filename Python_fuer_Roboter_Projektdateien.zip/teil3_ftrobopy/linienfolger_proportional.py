# ============================================================
# PROJEKT: Linienfolger mit proportionaler Steuerung
# Je staerker die Abweichung zwischen linkem und rechtem Sensor,
# desto staerker lenkt der Roboter gegen.
# ============================================================

import ftrobopy
from time import sleep

txt = ftrobopy.ftrobopy("localhost", 65000)

motor_links = txt.motor(1)     # Motor an M1
motor_rechts = txt.motor(2)    # Motor an M2
sensor_links = txt.voltage(1)   # Sensor an I1
sensor_rechts = txt.voltage(2)  # Sensor an I2

GRUNDGESCHWINDIGKEIT = 300
VERSTAERKUNG = 1.5   # entspricht dem "KP" aus dem PID-Kapitel

print("Linienfolger gestartet.")

while True:
    wert_links = sensor_links.voltage()
    wert_rechts = sensor_rechts.voltage()

    # Fehler = Unterschied zwischen den beiden Sensoren.
    # Positiv, wenn der linke Sensor mehr Licht sieht als der rechte.
    fehler = wert_links - wert_rechts

    lenkung = fehler * VERSTAERKUNG

    speed_links = GRUNDGESCHWINDIGKEIT - lenkung
    speed_rechts = GRUNDGESCHWINDIGKEIT + lenkung

    # Geschwindigkeiten auf den erlaubten Bereich begrenzen
    speed_links = max(-512, min(512, speed_links))
    speed_rechts = max(-512, min(512, speed_rechts))

    motor_links.setSpeed(int(speed_links))
    motor_rechts.setSpeed(int(speed_rechts))

    sleep(0.02)
