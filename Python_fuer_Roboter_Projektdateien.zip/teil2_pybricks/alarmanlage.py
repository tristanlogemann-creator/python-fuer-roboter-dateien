# ============================================================
# PROJEKT: Alarmanlage
# Scharf schalten mit der mittleren Taste, unscharf schalten mit
# der linken Taste. Im scharfen Zustand ueberwacht die Anlage
# Abstand UND Kraftsensor gleichzeitig.
# ============================================================

from pybricks.hubs import PrimeHub
from pybricks.pupdevices import UltrasonicSensor, ForceSensor
from pybricks.parameters import Port, Button, Color, Icon
from pybricks.tools import wait

hub = PrimeHub()
# Center-Taste ist normalerweise die Stopp-Taste - hier freigeben,
# damit wir sie zum Scharfstellen benutzen koennen (siehe Kapitel 2.3):
hub.system.set_stop_button((Button.CENTER, Button.BLUETOOTH))

abstandssensor = UltrasonicSensor(Port.C)
kraftsensor = ForceSensor(Port.D)

# Eigenes Ausrufezeichen-Muster, siehe "eigenes Muster" in Kapitel 2.3 -
# ein fertiges Icon.EXCLAMATION gibt es in Pybricks naemlich nicht.
ausrufezeichen = [
    [0, 0, 100, 0, 0],
    [0, 0, 100, 0, 0],
    [0, 0, 100, 0, 0],
    [0, 0, 0, 0, 0],
    [0, 0, 100, 0, 0],
]

ALARM_ABSTAND_MM = 300   # Bereich, der ueberwacht wird
scharf = False

hub.light.on(Color.WHITE)
print("Alarmanlage bereit. Mittlere Taste = scharf, linke Taste = unscharf.")

while True:
    tasten = hub.buttons.pressed()

    # --- Scharf- / Unscharfschalten ueber die Tasten ------------
    if Button.CENTER in tasten and not scharf:
        scharf = True
        hub.light.on(Color.RED)
        hub.display.icon(Icon.ARROW_RIGHT_UP)   # als "Scharf"-Symbol
        print("Alarmanlage ist jetzt SCHARF.")
        wait(500)   # kurze Pause, damit der Tastendruck nicht doppelt zaehlt

    elif Button.LEFT in tasten and scharf:
        scharf = False
        hub.light.on(Color.GREEN)
        hub.display.off()
        print("Alarmanlage ist jetzt UNSCHARF.")
        wait(500)

    # --- Ueberwachung, nur wenn scharf geschaltet ----------------
    if scharf:
        abstand = abstandssensor.distance()
        beruehrt = kraftsensor.pressed()

        if abstand < ALARM_ABSTAND_MM or beruehrt:
            # ALARM! Licht blinkt, Hub zeigt Ausrufezeichen
            print("ALARM! Eindringling erkannt!")
            for _ in range(10):
                hub.light.on(Color.RED)
                hub.display.icon(ausrufezeichen)
                wait(150)
                hub.light.on(Color.YELLOW)
                hub.display.off()
                wait(150)

    wait(50)
