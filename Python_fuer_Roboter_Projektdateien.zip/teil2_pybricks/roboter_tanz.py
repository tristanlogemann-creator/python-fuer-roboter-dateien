# ============================================================
# BONUS-PROJEKT: Roboter-Tanz-Choreografie
# Jeder "Tanzschritt" ist eine eigene Funktion. Die Choreografie
# am Ende ist einfach eine Liste von Funktionsaufrufen.
# ============================================================

from pybricks.hubs import PrimeHub
from pybricks.pupdevices import Motor
from pybricks.parameters import Port, Color, Icon, Direction
from pybricks.robotics import DriveBase
from pybricks.tools import wait

hub = PrimeHub()
linker_motor = Motor(Port.A, positive_direction=Direction.COUNTERCLOCKWISE)
rechter_motor = Motor(Port.B, positive_direction=Direction.CLOCKWISE)
antrieb = DriveBase(linker_motor, rechter_motor,
                     wheel_diameter=56, axle_track=114)


def wackler(anzahl):
    # Tanzschritt 1: schnelles Hin-und-Her-Drehen
    for _ in range(anzahl):
        antrieb.turn(20)
        antrieb.turn(-20)


def drehung_mit_farbwechsel():
    # Tanzschritt 2: eine volle Drehung, dabei wechselt die Hub-Farbe
    farben = [Color.RED, Color.YELLOW, Color.GREEN, Color.BLUE]
    for farbe in farben:
        hub.light.on(farbe)
        antrieb.turn(90)


def hueftschwung(mm):
    # Tanzschritt 3: seitliches Wackeln durch kurze Vor-/Zurueckbewegungen
    antrieb.straight(mm)
    antrieb.straight(-mm)


def finale():
    # Grosses Finale: Herzsymbol auf dem Display und eine letzte Drehung
    hub.display.icon(Icon.HEART)
    antrieb.turn(360)
    hub.light.on(Color.MAGENTA)


# --- Die eigentliche Choreografie ---------------------------
# Einfach eine Liste von "Schritten" - leicht zu aendern und zu erweitern!
print("Die Show beginnt!")

wackler(3)
wait(300)
drehung_mit_farbwechsel()
wait(300)
hueftschwung(100)
wait(300)
finale()

print("Vorhang!")
