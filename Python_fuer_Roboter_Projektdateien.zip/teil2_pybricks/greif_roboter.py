# ============================================================
# PROJEKT: Greif-Roboter
# Faehrt vorwaerts, schliesst den Greifer bis Kontakt erkannt
# wird, faehrt rueckwaerts und legt das Objekt wieder ab.
# ============================================================

from pybricks.hubs import PrimeHub
from pybricks.pupdevices import Motor, ForceSensor
from pybricks.parameters import Port, Color, Direction
from pybricks.robotics import DriveBase
from pybricks.tools import wait

hub = PrimeHub()

linker_motor = Motor(Port.A, positive_direction=Direction.COUNTERCLOCKWISE)
rechter_motor = Motor(Port.B, positive_direction=Direction.CLOCKWISE)
antrieb = DriveBase(linker_motor, rechter_motor,
                     wheel_diameter=56, axle_track=114)
greifarm = Motor(Port.C)
kraftsensor = ForceSensor(Port.D)


def greifer_schliessen():
    print("Greife zu...")
    greifarm.run(200)   # langsam schliessen
    while not kraftsensor.pressed():
        wait(20)
    greifarm.hold()
    print("Objekt gegriffen!")


def greifer_oeffnen():
    print("Oeffne Greifer...")
    greifarm.run_angle(300, -90)   # zurueck in die Ausgangsposition


# --- Ablauf -----------------------------------------------
hub.light.on(Color.ORANGE)
antrieb.straight(300)     # zum Objekt fahren

greifer_schliessen()

antrieb.straight(-300)    # rueckwaerts zur Ablagestelle
antrieb.turn(180)

greifer_oeffnen()
hub.light.on(Color.GREEN)
print("Aufgabe abgeschlossen!")
