# ============================================================
# PROJEKT: PID-Linienfolger
# Der Farbsensor misst die Helligkeit unter dem Roboter. Ziel ist
# ein Zielwert genau am Rand der schwarzen Linie (ZIEL_HELLIGKEIT).
# ============================================================

from pybricks.hubs import PrimeHub
from pybricks.pupdevices import Motor, ColorSensor
from pybricks.parameters import Port, Direction
from pybricks.robotics import DriveBase
from pybricks.tools import wait

hub = PrimeHub()

linker_motor = Motor(Port.A, positive_direction=Direction.COUNTERCLOCKWISE)
rechter_motor = Motor(Port.B, positive_direction=Direction.CLOCKWISE)
farbsensor = ColorSensor(Port.C)
# Wichtig: Sensor so montieren, dass die Linie bei korrekter Spur RECHTS vom
# Sensor liegt (er sitzt also an der LINKEN Kante der Linie). Ist dein Aufbau
# spiegelverkehrt, siehe Hinweis weiter unten im Buch (Vorzeichen umkehren).

antrieb = DriveBase(linker_motor, rechter_motor,
                     wheel_diameter=56, axle_track=114)

# --- PID-Einstellungen (hier feilst du am meisten!) ----------
ZIEL_HELLIGKEIT = 50    # Sensorwert genau am Linienrand (0-100)
KP = 1.2                # Verstaerkung des P-Anteils
KI = 0.02               # Verstaerkung des I-Anteils
KD = 0.8                # Verstaerkung des D-Anteils
GRUNDGESCHWINDIGKEIT = 150   # mm/s Vorwaertsgeschwindigkeit
FEHLER_SUMME_MAX = 500      # Begrenzung (Anti-Windup) des I-Anteils
LENKUNG_MAX = 200           # harte Lenkausschlaege begrenzen

fehler_summe = 0          # fuer den I-Anteil
letzter_fehler = 0        # fuer den D-Anteil

while True:
    helligkeit = farbsensor.reflection()

    # Fehler = Abweichung vom Zielwert (kann negativ oder positiv sein)
    fehler = helligkeit - ZIEL_HELLIGKEIT

    fehler_summe = fehler_summe + fehler
    # Begrenzung (Anti-Windup): sonst waechst fehler_summe unbegrenzt an,
    # z.B. wenn der Roboter die Linie kurz verliert.
    fehler_summe = max(-FEHLER_SUMME_MAX, min(FEHLER_SUMME_MAX, fehler_summe))
    fehler_aenderung = fehler - letzter_fehler

    # Die PID-Formel: alle drei Anteile gewichtet aufsummieren
    lenkung = (KP * fehler) + (KI * fehler_summe) + (KD * fehler_aenderung)
    # Auch die Lenkung selbst begrenzen, damit kein Ausreisser zu hart einlenkt
    lenkung = max(-LENKUNG_MAX, min(LENKUNG_MAX, lenkung))

    letzter_fehler = fehler

    # Lenkung an die DriveBase uebergeben: drive(speed, turn_rate)
    antrieb.drive(GRUNDGESCHWINDIGKEIT, lenkung)

    wait(10)   # kleine, konstante Regelschleifen-Zeit
