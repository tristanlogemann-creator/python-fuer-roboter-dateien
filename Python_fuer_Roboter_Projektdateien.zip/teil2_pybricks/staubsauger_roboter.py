# ============================================================
# PROJEKT: Autonomer Staubsauger-Roboter
# Faehrt selbststaendig, weicht Hindernissen aus, wiederholt das
# endlos - genau wie ein echter Saugroboter.
# ============================================================

from pybricks.hubs import PrimeHub
from pybricks.pupdevices import Motor, UltrasonicSensor
from pybricks.parameters import Port, Color, Direction
from pybricks.robotics import DriveBase
from pybricks.tools import wait, StopWatch
from urandom import randint   # fuer zufaellige Ausweichwinkel

hub = PrimeHub()

# --- Hardware einrichten -----------------------------------
linker_motor = Motor(Port.A, positive_direction=Direction.COUNTERCLOCKWISE)
rechter_motor = Motor(Port.B, positive_direction=Direction.CLOCKWISE)
abstandssensor = UltrasonicSensor(Port.C)

antrieb = DriveBase(linker_motor, rechter_motor,
                     wheel_diameter=56, axle_track=114)
antrieb.settings(straight_speed=200, turn_rate=120)

# --- Einstellungen -------------------------------------------
SICHERHEITSABSTAND_MM = 150   # ab hier wird ausgewichen
ZEIT_PRO_ETAPPE_S = 3         # nach dieser Zeit kurz die Richtung pruefen

hub.light.on(Color.GREEN)
print("Staubsauger-Roboter gestartet!")

timer = StopWatch()

# --- Hauptschleife: laeuft dauerhaft -------------------------
while True:
    abstand = abstandssensor.distance()

    if abstand < SICHERHEITSABSTAND_MM:
        # Hindernis erkannt: anhalten, kurz zurueckfahren, zufaellig drehen
        antrieb.stop()
        hub.light.on(Color.ORANGE)
        print(f"Hindernis bei {abstand} mm - weiche aus.")

        antrieb.straight(-80)               # ein Stueck zurueckfahren
        zufalls_winkel = randint(60, 180)   # zufaelliger Drehwinkel
        antrieb.turn(zufalls_winkel)

        hub.light.on(Color.GREEN)
        timer.reset()

    else:
        # Weg ist frei: geradeaus weiterfahren (nicht blockierend)
        antrieb.straight(300, wait=False)

        # Alle paar Sekunden pruefen wir trotzdem den Fortschritt
        if timer.time() > ZEIT_PRO_ETAPPE_S * 1000:
            timer.reset()

    wait(50)
